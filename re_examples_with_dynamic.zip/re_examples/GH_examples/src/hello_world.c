#include <stdio.h>

int main() {

   int secret_var = 123;

   printf("Hello World\n");
   return 0;
}
