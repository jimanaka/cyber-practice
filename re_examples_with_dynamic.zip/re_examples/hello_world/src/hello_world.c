#include <stdio.h>

int main() {
	int secret = 1234;
	char *secret_string = "you shouldn't be here!";

	printf("Hello, world\n");
	return 0;
}
