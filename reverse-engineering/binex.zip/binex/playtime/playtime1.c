#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>


#define BUFFSIZE 64
#define FLAGSIZE 64

void flag() {
  char buf[FLAGSIZE];
  FILE *f = fopen("flag.txt","r");
  if (f == NULL) {
    printf("Flag File is Missing.\n");
    exit(0);
  }

  fgets(buf,FLAGSIZE,f);
  printf(buf);
}

void vuln(){
  char buf[BUFFSIZE];
  gets(buf);
  printf("Woah, he pounced to 0x%x!\n", __builtin_return_address(0));
}

int main(int argc, char **argv){
  setvbuf(stdout, NULL, _IONBF, 0);
  gid_t gid = getegid();
  setresgid(gid, gid, gid);

  printf("       |\\__/,|   (`\\\n");
  printf("     _.|o o  |_   ) )\n");
  printf("----(((---(((--------\n");
  puts("Give a cat some string and lets see what happens: ");
  vuln();
  return 0;
}

